# FlutterInspect

A Zygisk module that enumerates and resolves **Dart/Flutter function addresses at runtime** — inside
the live app process, ASLR-corrected, no Frida, no offline analysis.

Forked from [FlutterTap](https://github.com/script-or-script/FlutterTap) by Eduardo Lopes.

---

## What it does

Flutter AOT apps embed function/class names as string literals in `.rodata` for stack traces and
reflection. FlutterInspect:

1. Injects into the target app via Zygisk (Magisk / KernelSU / APatch)
2. Waits for `libapp.so` (or `libflutter.so`) to load
3. Scans `.rodata` for Dart identifier strings matching your keywords (or all of them)
4. Disassembles `.text` with **Capstone** to find which functions reference those strings
5. Reports: function name · runtime address · **offset from base** (paste directly into Frida)

## Why

The normal workflow is: extract APK → run [blutter](https://github.com/worawit/blutter) offline → get
offsets → write Frida script with hardcoded offsets → spawn with frida-server. That's fragile,
slow, and breaks on ASLR. FlutterInspect gives you **live, ASLR-corrected offsets** with no cable
required and no offline analysis step.

---

## Requirements

- Rooted Android 10+ device
- Magisk with Zygisk enabled, **or** KernelSU + Zygisk Next / NeoZygisk, **or** APatch
- Architectures: `arm64-v8a`, `x86_64`
- [Android NDK 27.2](https://developer.android.com/ndk/downloads) + Android Studio / Gradle

---

## Build

### 1. Clone with submodules

```sh
git clone --recursive https://github.com/your-fork/FlutterInspect
```

Or after cloning:
```sh
git submodule update --init --recursive
```

This pulls in:
- `module/src/main/cpp/third_party/capstone` — Capstone disassembly engine
- `module/src/main/cpp/include/zygisk.hpp` — Zygisk API header

### 2. Build

```sh
./gradlew :module:assembleRelease
```

The Zygisk `.so` files land in:
```
module/build/intermediates/stripped_native_libs/release/
```

### 3. Package as Magisk module

The build script (TODO: `scripts/build_module_zip.sh`) packages the `.so` files into the
`zygisk/` folder layout that Magisk expects and zips with the template files from
`module/template/`.

---

## Usage (Phase 1 — no manager app)

### Step 1: Write your config

Edit one of the example configs and push it:

```sh
# Keyword search (find functions that reference specific class/method names):
adb push config_keyword_example.json /data/local/tmp/flutterlens_config.json

# Full enumerate (dump all Dart-looking strings and their functions):
adb push config_enumerate_example.json /data/local/tmp/flutterlens_config.json
```

Replace `"com.example.flutterapp"` with the actual package name of your target.

### Step 2: Install the module

Flash the module zip via Magisk / MMRL / KSU WebUI. Reboot.

### Step 3: Launch the target app

Open the Flutter app normally. The module injects automatically.

### Step 4: Read results

**Via logcat** (live, filtered):
```sh
adb logcat -s FlutterInspect:V
```

**Via JSON file** (pull after the app has started):
```sh
adb pull /data/local/tmp/flutterlens_com.example.flutterapp.json
```

### Step 5: Use offsets in Frida

Results include `offset` — the function's address relative to the library base:

```javascript
// From the JSON: "name": "LoginBloc.authenticate", "offset": "0x44780", "lib": "libapp.so"
const base   = Module.findBaseAddress("libapp.so");
const target = base.add(0x44780);
Interceptor.attach(target, {
    onEnter(args) { console.log("LoginBloc.authenticate called!"); },
    onLeave(retval) { console.log("returned:", retval); }
});
```

---

## Output format

```json
{
  "process": "com.example.flutterapp",
  "lib": "libapp.so",
  "lib_base": "0x70abc12000",
  "count": 3,
  "functions": [
    {
      "name": "LoginBloc.authenticate",
      "abs_addr": "0x70abc56780",
      "offset": "0x44780",
      "xref_addr": "0x70abc56740"
    }
  ]
}
```

| Field       | Meaning |
|---|---|
| `name`      | The Dart string literal that anchored the search |
| `abs_addr`  | Actual runtime address (ASLR-resolved) |
| `offset`    | `abs_addr - lib_base` — use in Frida scripts |
| `xref_addr` | Address of the `adrp`/`lea` instruction that referenced the string |

---

## How it works (technical)

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full write-up.

Short version: Dart AOT embeds `ClassName.methodName` strings in `.rodata`. On arm64, code loads
those strings via `adrp`/`add` instruction pairs. FlutterInspect scans `.text` for `adrp`
instructions that compute addresses landing in the same 4 KB page as your keyword string, validates
the matching `add`, then backtracks to the function prologue (`stp x29, x30, [sp, #-N]!`).
On x86_64 it scans for `lea reg, [rip+disp]`. All memory reads go through a SIGSEGV-guarded
`safe_read()` so a bad scan result can't crash the host app.

---

## Project structure

```
FlutterInspect/
├── module/src/main/cpp/
│   ├── main.cpp          # Zygisk lifecycle
│   ├── elf_utils.*       # dl_iterate_phdr + ELF segment parsing
│   ├── mem_scan.*        # SIGSEGV-guarded memory scan + safe_read
│   ├── rodata_scan.*     # .rodata string scanner (keyword + full enumerate)
│   ├── dart_resolver.*   # string → function address (Capstone-based)
│   ├── result_writer.*   # logcat + JSON output
│   ├── companion.*       # root companion (reads config file)
│   ├── module_config.*   # config struct + JSON parser
│   ├── json_min.*        # minimal JSON parser
│   └── third_party/
│       └── capstone/     # git submodule
├── config_keyword_example.json
├── config_enumerate_example.json
└── README.md
```

---

## Roadmap

- [x] **Phase 1a** — keyword search + full .rodata enumeration (this release)
- [ ] **Phase 1b** — performance: single-pass .text xref map for full enumeration
- [x] **Phase 2**  — Manager app (Jetpack Compose) for on-device search + Frida snippet copy
- [ ] **Phase 2**  — Dart VM snapshot cluster walker (structured class/function table, no heuristics)

---

## Credits

- [FlutterTap](https://github.com/script-or-script/FlutterTap) by Eduardo Lopes — Zygisk module
  architecture, ELF parsing, safe_read / crash guard, Capstone integration
- [Capstone](https://www.capstone-engine.org/) — disassembly engine
- [Zygisk API](https://github.com/topjohnwu/zygisk-module-sample)
- [blutter](https://github.com/worawit/blutter) — inspiration for offline Dart function analysis
