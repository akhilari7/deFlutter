// FlutterInspect native module
// Forked from FlutterTap by Eduardo Lopes. FlutterInspect by Akshay Khilari.
#include "module_config.h"

#include "json_min.h"
#include "log.h"

bool ModuleConfig::isTargeted(const std::string &process_name) const {
    if (!enabled) return false;
    for (const auto &pkg : target_packages) {
        if (process_name == pkg) return true;
        // Match named sub/isolate processes, e.g. "com.pkg:remote".
        if (process_name.size() > pkg.size() + 1 &&
            process_name.compare(0, pkg.size(), pkg) == 0 &&
            process_name[pkg.size()] == ':') {
            return true;
        }
    }
    return false;
}

ModuleConfig module_config_parse(const std::string &json_text) {
    ModuleConfig cfg; // defaults

    if (json_text.empty()) return cfg;

    JsonValue root;
    if (!json_parse(json_text, root) || !root.isObject()) {
        fi_log_warn("module_config: failed to parse JSON — using defaults");
        return cfg;
    }

    // enabled
    if (const auto *v = root.get("enabled"); v && v->isBool()) {
        cfg.enabled = v->asBool(true);
    }

    // target_packages
    if (const auto *v = root.get("target_packages"); v && v->isArray()) {
        cfg.target_packages.clear();
        for (const auto &elem : v->arrValue) {
            if (elem.isString() && !elem.strValue.empty()) {
                cfg.target_packages.push_back(elem.strValue);
            }
        }
    }

    // mode
    if (const auto *v = root.get("mode"); v && v->isString()) {
        if (v->strValue == "full_enumerate") {
            cfg.mode = ModuleConfig::Mode::FULL_ENUMERATE;
        } else {
            cfg.mode = ModuleConfig::Mode::KEYWORD_SEARCH;
        }
    }

    // keywords (only relevant for KEYWORD_SEARCH mode)
    if (const auto *v = root.get("keywords"); v && v->isArray()) {
        cfg.keywords.clear();
        for (const auto &elem : v->arrValue) {
            if (elem.isString() && !elem.strValue.empty()) {
                cfg.keywords.push_back(elem.strValue);
            }
        }
    }

    fi_log_info("module_config: enabled=%d mode=%s targets=%zu keywords=%zu",
                cfg.enabled,
                cfg.mode == ModuleConfig::Mode::FULL_ENUMERATE ? "full_enumerate" : "keyword_search",
                cfg.target_packages.size(),
                cfg.keywords.size());

    return cfg;
}
