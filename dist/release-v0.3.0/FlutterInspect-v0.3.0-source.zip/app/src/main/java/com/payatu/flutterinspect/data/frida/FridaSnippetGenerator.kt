package com.payatu.flutterinspect.data.frida

import com.payatu.flutterinspect.data.models.FunctionEntry

object FridaSnippetGenerator {

    enum class TemplateType(val title: String, val description: String) {
        BASIC_TRACE(
            "Basic Call Tracer",
            "Logs when the target function is invoked with runtime timestamp and ASLR address."
        ),
        DART_ARG_INSPECTOR(
            "Dart AOT Argument Inspector",
            "Universal ARM64 inspector: decodes x15 stack, [FP+0x10], [FP+0x18], Smi, and OneByteString values."
        ),
        MULTI_FUNCTION_BATCH(
            "Batch Multi-Hook",
            "Hooks all filtered functions simultaneously with offset tracking."
        )
    }

    fun generateSnippet(
        templateType: TemplateType,
        targetLib: String,
        targetFunc: FunctionEntry?,
        allFuncs: List<FunctionEntry> = emptyList()
    ): String {
        return when (templateType) {
            TemplateType.BASIC_TRACE -> generateBasicHook(targetLib, targetFunc)
            TemplateType.DART_ARG_INSPECTOR -> generateDartArgInspector(targetLib, targetFunc)
            TemplateType.MULTI_FUNCTION_BATCH -> generateBatchHook(targetLib, allFuncs)
        }
    }

    private fun generateBasicHook(targetLib: String, func: FunctionEntry?): String {
        val name = func?.name ?: "target_function"
        val offset = func?.offset ?: "0x0"

        return """
            /**
             * FlutterInspect Frida Script: Basic Function Tracer
             * Target: $name
             * Module: $targetLib (Offset: $offset)
             */
            'use strict';

            const TARGET_MODULE = "$targetLib";
            const TARGET_OFFSET = $offset;
            const FUNC_NAME = "$name";

            function attachHook() {
                const mod = Process.findModuleByName(TARGET_MODULE);
                if (!mod) {
                    console.log(`[-] Waiting for module ` + TARGET_MODULE + `...`);
                    return false;
                }
                const targetAddr = mod.base.add(TARGET_OFFSET);
                console.log(`[+] Attaching to ` + FUNC_NAME + ` at ` + targetAddr + ` (Base: ` + mod.base + `)`);

                Interceptor.attach(targetAddr, {
                    onEnter: function(args) {
                        console.log(`\n[★] Hit ` + FUNC_NAME + ` @ ` + targetAddr);
                        console.log(`    Thread ID: ` + Process.getCurrentThreadId());
                        console.log(`    Return Address: ` + this.returnAddress);
                    },
                    onLeave: function(retval) {
                        console.log(`[★] Left ` + FUNC_NAME + ` -> Retval: ` + retval);
                    }
                });
                return true;
            }

            if (!attachHook()) {
                const interval = setInterval(() => {
                    if (attachHook()) clearInterval(interval);
                }, 500);
            }
        """.trimIndent()
    }

    private fun generateDartArgInspector(targetLib: String, func: FunctionEntry?): String {
        val name = func?.name ?: "target_function"
        val offset = func?.offset ?: "0x0"

        return """
            /**
             * FlutterInspect: Dart ARM64 AOT Runtime Argument Inspector
             * Target: $name ($offset) in $targetLib
             * 
             * Decodes:
             *  - x15 Dart Stack Pointer & x29 Dart Frame Pointer
             *  - [FP + 0x10] (Arg 0 / Receiver), [FP + 0x18] (Arg 1 / Input), [FP + 0x20] (Arg 2)
             *  - Registers x0..x3 fallbacks
             *  - Smi (Bit 0 == 0) & HeapObject OneByteString (Bit 0 == 1)
             */
            'use strict';

            const TARGET_MODULE = "$targetLib";
            const TARGET_OFFSET = $offset;
            const FUNC_NAME = "$name";

            // Universal Dart AOT Type Decoder
            function decodeDartValue(ptr) {
                if (!ptr || ptr.isNull()) return "null";
                const p = ptr.toUInt53 ? ptr : ptr(ptr);
                
                // 1. Check for Smi (Small Integer, LSB == 0)
                if (ptr.and(1).isNull()) {
                    return `Smi(` + ptr.shr(1).toString() + `)`;
                }

                // 2. HeapObject (LSB == 1 -> untag by subtracting 1)
                const untagged = ptr.sub(1);
                try {
                    // OneByteString layout:
                    // +0x00: Class header (Class ID / GC tags)
                    // +0x08: Length as tagged Smi
                    // +0x10: Character payload
                    const smiLen = untagged.add(8).readPointer();
                    if (smiLen.and(1).isNull()) {
                        const len = smiLen.shr(1).toInt32();
                        if (len >= 0 && len < 2048) {
                            const strBytes = untagged.add(16).readUtf8String(len);
                            if (strBytes !== null) {
                                return `String("` + strBytes + `")`;
                            }
                        }
                    }
                } catch (e) {
                    // Not a valid string object or protected page
                }

                return `HeapObj(` + ptr + ` -> untagged: ` + untagged + `)`;
            }

            function attachHook() {
                const mod = Process.findModuleByName(TARGET_MODULE);
                if (!mod) return false;

                const targetAddr = mod.base.add(TARGET_OFFSET);
                console.log(`[+] Hooked ` + FUNC_NAME + ` @ ` + targetAddr);

                Interceptor.attach(targetAddr, {
                    onEnter: function(args) {
                        const fp = this.context.x29; // Dart Frame Pointer
                        const dartSp = this.context.x15; // Reserved Dart SP

                        console.log(`\n======================================================`);
                        console.log(`[★] INVOCATION: ` + FUNC_NAME);
                        console.log(`    Target Addr: ` + targetAddr);
                        console.log(`    Dart FP (x29): ` + fp + ` | Dart SP (x15): ` + dartSp);

                        // Inspect Dart Stack Frame (Caller pushes args before call)
                        try {
                            const arg0 = fp.add(0x10).readPointer();
                            const arg1 = fp.add(0x18).readPointer();
                            const arg2 = fp.add(0x20).readPointer();

                            console.log(`    [FP + 0x10] (Arg 0): ` + decodeDartValue(arg0));
                            console.log(`    [FP + 0x18] (Arg 1): ` + decodeDartValue(arg1));
                            console.log(`    [FP + 0x20] (Arg 2): ` + decodeDartValue(arg2));
                        } catch (err) {
                            console.log(`    [!] Stack frame read error: ` + err.message);
                        }

                        // Inspect register fallbacks
                        console.log(`    Registers:`);
                        console.log(`      x0: ` + decodeDartValue(this.context.x0));
                        console.log(`      x1: ` + decodeDartValue(this.context.x1));
                        console.log(`      x2: ` + decodeDartValue(this.context.x2));
                        console.log(`      x3: ` + decodeDartValue(this.context.x3));
                        console.log(`======================================================`);
                    }
                });
                return true;
            }

            if (!attachHook()) {
                const iv = setInterval(() => {
                    if (attachHook()) clearInterval(iv);
                }, 500);
            }
        """.trimIndent()
    }

    private fun generateBatchHook(targetLib: String, funcs: List<FunctionEntry>): String {
        val targetsJson = funcs.take(30).map { f ->
            "    { name: \"${f.name.replace("\"", "\\\"")}\", offset: ${f.offset} }"
        }.joinToString(",\n")

        return """
            /**
             * FlutterInspect Batch Hook Script
             * Targets: ${funcs.size} resolved Dart functions in $targetLib
             */
            'use strict';

            const TARGET_MODULE = "$targetLib";
            const HOOK_TARGETS = [
            $targetsJson
            ];

            function setupBatchHooks() {
                const mod = Process.findModuleByName(TARGET_MODULE);
                if (!mod) {
                    console.log(`[-] Waiting for ` + TARGET_MODULE + `...`);
                    return false;
                }

                console.log(`[+] Attached to ` + TARGET_MODULE + ` base: ` + mod.base);
                let attachedCount = 0;

                HOOK_TARGETS.forEach(target => {
                    try {
                        const targetAddr = mod.base.add(target.offset);
                        Interceptor.attach(targetAddr, {
                            onEnter: function(args) {
                                console.log(`[+] HIT: ` + target.name + ` @ ` + targetAddr + ` (offset: ` + ptr(target.offset) + `)`);
                            }
                        });
                        attachedCount++;
                    } catch (e) {
                        console.log(`[-] Failed to hook ` + target.name + `: ` + e.message);
                    }
                });

                console.log(`[+] Successfully hooked ` + attachedCount + ` / ` + HOOK_TARGETS.length + ` functions.`);
                return true;
            }

            if (!setupBatchHooks()) {
                const interval = setInterval(() => {
                    if (setupBatchHooks()) clearInterval(interval);
                }, 500);
            }
        """.trimIndent()
    }
}
