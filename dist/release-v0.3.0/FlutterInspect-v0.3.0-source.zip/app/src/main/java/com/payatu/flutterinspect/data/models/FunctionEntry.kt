package com.payatu.flutterinspect.data.models

data class FunctionEntry(
    val name: String = "",
    val absAddr: String = "",
    val offset: String = "",
    val xrefAddr: String = ""
) {
    /**
     * Checks if search query matches name or offset
     */
    fun matches(query: String): Boolean {
        if (query.isBlank()) return true
        val q = query.trim().lowercase()
        return name.lowercase().contains(q) ||
               offset.lowercase().contains(q) ||
               absAddr.lowercase().contains(q)
    }
}
