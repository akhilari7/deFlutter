package com.payatu.flutterinspect.data.shell

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.payatu.flutterinspect.data.models.DartSnapshot
import com.payatu.flutterinspect.data.models.FunctionEntry
import com.payatu.flutterinspect.data.models.InspectConfig
import com.payatu.flutterinspect.data.models.InstalledApp
import com.payatu.flutterinspect.data.models.ScanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.zip.ZipFile

object RootShell {

    private const val PRIMARY_CONFIG_PATH = "/data/adb/flutterlens/config.json"
    private const val FALLBACK_CONFIG_PATH = "/data/local/tmp/flutterlens_config.json"

    data class CommandResult(val exitCode: Int, val stdout: String, val stderr: String)

    suspend fun execSu(command: String): CommandResult = withContext(Dispatchers.IO) {
        try {
            android.util.Log.d("FlutterInspect", "execSu CMD: $command")
            // Use su -mm to enter global mount namespace (crucial for accessing other apps' /data/data)
            val process = try {
                ProcessBuilder("su", "-mm").redirectErrorStream(false).start()
            } catch (_: Exception) {
                ProcessBuilder("su").redirectErrorStream(false).start()
            }
            
            // Write command followed by exit to su stdin
            process.outputStream.bufferedWriter().use { writer ->
                writer.write(command)
                writer.newLine()
                writer.write("exit")
                writer.newLine()
                writer.flush()
            }

            val stdout = process.inputStream.bufferedReader().use(BufferedReader::readText).trim()
            val stderr = process.errorStream.bufferedReader().use(BufferedReader::readText).trim()
            val code = process.waitFor()

            android.util.Log.d("FlutterInspect", "execSu EXIT: $code | STDOUT: ${stdout.take(100)} | STDERR: $stderr")
            CommandResult(code, stdout, stderr)
        } catch (e: Exception) {
            android.util.Log.e("FlutterInspect", "execSu EXCEPTION: ${e.message}", e)
            CommandResult(-1, "", e.message ?: "Execution failed")
        }
    }

    suspend fun isRootAvailable(): Boolean = withContext(Dispatchers.IO) {
        val res = execSu("id")
        res.exitCode == 0 && res.stdout.contains("uid=0")
    }

    suspend fun saveConfig(config: InspectConfig): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = config.toJsonString().replace("\"", "\\\"").replace("\n", " ")
            val dirCmd = "mkdir -p /data/adb/flutterlens"
            execSu(dirCmd)

            // Write to primary and fallback
            val writeCmd = "echo \"$json\" > $PRIMARY_CONFIG_PATH && chmod 666 $PRIMARY_CONFIG_PATH && " +
                           "echo \"$json\" > $FALLBACK_CONFIG_PATH && chmod 666 $FALLBACK_CONFIG_PATH"
            val res = execSu(writeCmd)
            if (res.exitCode == 0) {
                Result.success("Config saved to $PRIMARY_CONFIG_PATH & $FALLBACK_CONFIG_PATH")
            } else {
                Result.failure(Exception("Failed to save config: ${res.stderr}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun loadCurrentConfig(): InspectConfig? = withContext(Dispatchers.IO) {
        val res1 = execSu("cat $PRIMARY_CONFIG_PATH")
        if (res1.exitCode == 0 && res1.stdout.isNotBlank()) {
            return@withContext InspectConfig.fromJsonString(res1.stdout)
        }
        val res2 = execSu("cat $FALLBACK_CONFIG_PATH")
        if (res2.exitCode == 0 && res2.stdout.isNotBlank()) {
            return@withContext InspectConfig.fromJsonString(res2.stdout)
        }
        null
    }

    suspend fun loadScanResult(packageName: String): Result<ScanResult> = withContext(Dispatchers.IO) {
        val safePkg = packageName.replace(":", "_")
        val possiblePaths = listOf(
            "/data/data/$packageName/cache/flutterlens.json",
            "/data/user/0/$packageName/cache/flutterlens.json",
            "/data/local/tmp/flutterlens_$safePkg.json",
            "/data/local/tmp/flutterlens.json"
        )

        for (path in possiblePaths) {
            val res = execSu("cat $path")
            if (res.exitCode == 0 && res.stdout.isNotBlank()) {
                try {
                    val root = JSONObject(res.stdout)
                    val proc = root.optString("process", packageName)
                    val lib = root.optString("lib", "libapp.so")
                    val libBase = root.optString("lib_base", "0x0")
                    val count = root.optInt("count", 0)

                    val funcs = mutableListOf<FunctionEntry>()
                    val arr = root.optJSONArray("functions")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val fObj = arr.getJSONObject(i)
                            funcs.add(
                                FunctionEntry(
                                    name = fObj.optString("name", "unknown"),
                                    absAddr = fObj.optString("abs_addr", "0x0"),
                                    offset = fObj.optString("offset", "0x0"),
                                    xrefAddr = fObj.optString("xref_addr", "0x0")
                                )
                            )
                        }
                    }

                    var snapshot: DartSnapshot? = null
                    val snapObj = root.optJSONObject("snapshot")
                    if (snapObj != null && snapObj.optBoolean("valid", false)) {
                        val symList = mutableListOf<String>()
                        val symArr = snapObj.optJSONArray("symbols")
                        if (symArr != null) {
                            for (s in 0 until symArr.length()) {
                                symList.add(symArr.getString(s))
                            }
                        }
                        snapshot = DartSnapshot(
                            valid = true,
                            magic = snapObj.optString("magic", ""),
                            kind = snapObj.optString("kind", ""),
                            hash = snapObj.optString("hash", ""),
                            features = snapObj.optString("features", ""),
                            numClusters = snapObj.optLong("num_clusters", 0L),
                            numObjects = snapObj.optLong("num_objects", 0L),
                            numBaseObjects = snapObj.optLong("num_base_objects", 0L),
                            instructionsOffset = snapObj.optString("instructions_offset", ""),
                            isolateDataAddr = snapObj.optString("isolate_data_addr", ""),
                            isolateInstructionsAddr = snapObj.optString("isolate_instructions_addr", ""),
                            symbolsCount = snapObj.optInt("symbols_count", symList.size),
                            symbols = symList
                        )
                    }

                    return@withContext Result.success(
                        ScanResult(
                            process = proc,
                            lib = lib,
                            libBase = libBase,
                            count = if (count > 0) count else funcs.size,
                            functions = funcs,
                            sourcePath = path,
                            snapshot = snapshot
                        )
                    )
                } catch (e: Exception) {
                    return@withContext Result.failure(e)
                }
            }
        }
        Result.failure(Exception("No result JSON found for $packageName in app cache or /data/local/tmp."))
    }

    suspend fun restartTargetApp(packageName: String): Result<String> = withContext(Dispatchers.IO) {
        val stopCmd = "am force-stop $packageName"
        execSu(stopCmd)
        // Launch app
        val launchCmd = "monkey -p $packageName -c android.intent.category.LAUNCHER 1"
        val launchRes = execSu(launchCmd)
        if (launchRes.exitCode == 0) {
            Result.success("Restarted $packageName")
        } else {
            Result.failure(Exception("Failed to launch $packageName: ${launchRes.stderr}"))
        }
    }

    suspend fun loadInstalledApps(context: Context): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)
        val list = mutableListOf<InstalledApp>()

        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem && !pkg.packageName.contains("flutter")) continue

            val appName = pm.getApplicationLabel(appInfo).toString()
            var isFlutter = false

            // Check nativeLibraryDir or APK for libflutter.so or libapp.so
            try {
                val libDir = File(appInfo.nativeLibraryDir)
                if (libDir.exists() && (File(libDir, "libflutter.so").exists() || File(libDir, "libapp.so").exists())) {
                    isFlutter = true
                } else if (appInfo.sourceDir != null) {
                    ZipFile(File(appInfo.sourceDir)).use { zip ->
                        isFlutter = zip.getEntry("lib/arm64-v8a/libflutter.so") != null ||
                                    zip.getEntry("lib/arm64-v8a/libapp.so") != null ||
                                    zip.getEntry("assets/flutter_assets/") != null
                    }
                }
            } catch (_: Exception) {}

            val icon = try { pm.getApplicationIcon(appInfo) } catch (_: Exception) { null }

            list.add(
                InstalledApp(
                    packageName = pkg.packageName,
                    appName = appName,
                    isFlutter = isFlutter,
                    icon = icon
                )
            )
        }

        // Sort Flutter apps first, then alphabetically
        list.sortedWith(compareByDescending<InstalledApp> { it.isFlutter }.thenBy { it.appName })
    }
}
