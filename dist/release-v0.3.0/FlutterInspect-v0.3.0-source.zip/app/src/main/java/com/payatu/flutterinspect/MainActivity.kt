package com.payatu.flutterinspect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.payatu.flutterinspect.ui.screens.MainScreen
import com.payatu.flutterinspect.ui.theme.FlutterInspectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FlutterInspectTheme {
                MainScreen()
            }
        }
    }
}
