package com.payatu.flutterinspect.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.payatu.flutterinspect.data.models.FunctionEntry
import com.payatu.flutterinspect.data.models.InspectConfig
import com.payatu.flutterinspect.data.models.InstalledApp
import com.payatu.flutterinspect.data.models.ScanResult
import com.payatu.flutterinspect.data.shell.RootShell
import com.payatu.flutterinspect.ui.components.AppTopBar
import com.payatu.flutterinspect.ui.theme.*
import kotlinx.coroutines.launch

enum class AppTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    CONFIG("Config", Icons.Default.Tune),
    FUNCTIONS("Functions", Icons.Default.ListAlt),
    FRIDA("Frida Lab", Icons.Default.Code)
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(AppTab.FUNCTIONS) }
    var isRootAvailable by remember { mutableStateOf(false) }

    var config by remember { mutableStateOf(InspectConfig()) }
    var installedApps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var scanResult by remember { mutableStateOf<ScanResult?>(null) }

    var isLoadingResults by remember { mutableStateOf(false) }
    var isSavingConfig by remember { mutableStateOf(false) }
    var isRestartingApp by remember { mutableStateOf(false) }

    var selectedFunctionForFrida by remember { mutableStateOf<FunctionEntry?>(null) }

    // Load initial data
    LaunchedEffect(Unit) {
        isRootAvailable = RootShell.isRootAvailable()

        // Load config from disk
        val currentCfg = RootShell.loadCurrentConfig()
        val activeProc = currentCfg?.process ?: config.process
        if (currentCfg != null) {
            config = currentCfg
        }

        // Load installed apps
        installedApps = RootShell.loadInstalledApps(context)

        // Load scan results
        isLoadingResults = true
        val res = RootShell.loadScanResult(activeProc)
        scanResult = res.getOrNull()
        isLoadingResults = false
    }

    val reloadData = {
        scope.launch {
            isLoadingResults = true
            isRootAvailable = RootShell.isRootAvailable()
            val currentCfg = RootShell.loadCurrentConfig()
            val activeProc = currentCfg?.process ?: config.process
            if (currentCfg != null) config = currentCfg

            val res = RootShell.loadScanResult(activeProc)
            scanResult = res.getOrNull()
            isLoadingResults = false

            if (scanResult != null) {
                Toast.makeText(context, "Loaded ${scanResult?.functions?.size} functions", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "No results file found for $activeProc", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                isRootAvailable = isRootAvailable,
                onRefresh = { reloadData() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SlateSurface,
                tonalElevation = 8.dp
            ) {
                AppTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyanPrimary,
                            selectedTextColor = CyanPrimary,
                            indicatorColor = CyanPrimary.copy(alpha = 0.15f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        },
        containerColor = SlateBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SlateBackground)
        ) {
            when (currentTab) {
                AppTab.CONFIG -> {
                    ConfigScreen(
                        config = config,
                        installedApps = installedApps,
                        onConfigChange = { config = it },
                        onSaveConfig = {
                            scope.launch {
                                isSavingConfig = true
                                val res = RootShell.saveConfig(config)
                                isSavingConfig = false
                                if (res.isSuccess) {
                                    Toast.makeText(context, "Configuration deployed to Zygisk!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onRestartApp = {
                            scope.launch {
                                isRestartingApp = true
                                RootShell.saveConfig(config)
                                val res = RootShell.restartTargetApp(config.process)
                                isRestartingApp = false
                                if (res.isSuccess) {
                                    Toast.makeText(context, "Restarted ${config.process}!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        isSaving = isSavingConfig,
                        isRestarting = isRestartingApp
                    )
                }

                AppTab.FUNCTIONS -> {
                    ResultsScreen(
                        scanResult = scanResult,
                        isLoading = isLoadingResults,
                        onReload = { reloadData() },
                        onInspectInFrida = { func ->
                            selectedFunctionForFrida = func
                            currentTab = AppTab.FRIDA
                        },
                        onBatchInspectInFrida = { _ ->
                            selectedFunctionForFrida = null
                            currentTab = AppTab.FRIDA
                        }
                    )
                }

                AppTab.FRIDA -> {
                    FridaStudioScreen(
                        targetLib = scanResult?.lib ?: "libapp.so",
                        selectedFunction = selectedFunctionForFrida,
                        allFunctions = scanResult?.functions ?: emptyList(),
                        onSelectFunction = { selectedFunctionForFrida = it }
                    )
                }
            }
        }
    }
}
