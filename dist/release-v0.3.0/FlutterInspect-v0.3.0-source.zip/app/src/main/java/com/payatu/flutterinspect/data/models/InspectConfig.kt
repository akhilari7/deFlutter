package com.payatu.flutterinspect.data.models

import org.json.JSONArray
import org.json.JSONObject

data class InspectConfig(
    val process: String = "co.ostorlab.insecure_app",
    val mode: String = "keyword_search", // "keyword_search" or "full_enumerate"
    val keywords: List<String> = listOf("command", "login", "http", "token"),
    val targetLibs: List<String> = listOf("libapp.so")
) {
    fun toJsonString(): String {
        val root = JSONObject()
        root.put("target_process", process)
        root.put("mode", mode)

        val kwArr = JSONArray()
        keywords.forEach { kwArr.put(it) }
        root.put("keywords", kwArr)

        val libArr = JSONArray()
        targetLibs.forEach { libArr.put(it) }
        root.put("target_libs", libArr)

        return root.toString(2)
    }

    companion object {
        fun fromJsonString(jsonStr: String): InspectConfig {
            return try {
                val obj = JSONObject(jsonStr)
                val proc = obj.optString("target_process", obj.optString("process", "co.ostorlab.insecure_app"))
                val m = obj.optString("mode", "keyword_search")

                val kws = mutableListOf<String>()
                val kwArr = obj.optJSONArray("keywords")
                if (kwArr != null) {
                    for (i in 0 until kwArr.length()) {
                        kws.add(kwArr.getString(i))
                    }
                }

                val libs = mutableListOf<String>()
                val libArr = obj.optJSONArray("target_libs")
                if (libArr != null) {
                    for (i in 0 until libArr.length()) {
                        libs.add(libArr.getString(i))
                    }
                }
                if (libs.isEmpty()) libs.add("libapp.so")

                InspectConfig(
                    process = proc,
                    mode = m,
                    keywords = if (kws.isEmpty()) listOf("command") else kws,
                    targetLibs = libs
                )
            } catch (e: Exception) {
                InspectConfig()
            }
        }
    }
}
