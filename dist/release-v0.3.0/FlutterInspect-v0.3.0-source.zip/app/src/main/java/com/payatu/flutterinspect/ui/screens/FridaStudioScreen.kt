package com.payatu.flutterinspect.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.payatu.flutterinspect.data.frida.FridaSnippetGenerator
import com.payatu.flutterinspect.data.models.FunctionEntry
import com.payatu.flutterinspect.ui.theme.*

@Composable
fun FridaStudioScreen(
    targetLib: String,
    selectedFunction: FunctionEntry?,
    allFunctions: List<FunctionEntry>,
    onSelectFunction: (FunctionEntry?) -> Unit
) {
    var selectedTemplate by remember { mutableStateOf(FridaSnippetGenerator.TemplateType.DART_ARG_INSPECTOR) }
    var showFunctionMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val scriptCode = remember(selectedTemplate, targetLib, selectedFunction, allFunctions) {
        FridaSnippetGenerator.generateSnippet(
            templateType = selectedTemplate,
            targetLib = targetLib.ifBlank { "libapp.so" },
            targetFunc = selectedFunction,
            allFuncs = allFunctions
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Target Header Card with Selector
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TARGET FUNCTION",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                        color = TextMuted
                    )

                    Box {
                        TextButton(
                            onClick = { showFunctionMenu = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text("Change", color = CyanPrimary, fontSize = 12.sp)
                        }

                        DropdownMenu(
                            expanded = showFunctionMenu,
                            onDismissRequest = { showFunctionMenu = false },
                            modifier = Modifier.background(SlateSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Functions (Batch Mode)", color = TextPrimary) },
                                onClick = {
                                    onSelectFunction(null)
                                    selectedTemplate = FridaSnippetGenerator.TemplateType.MULTI_FUNCTION_BATCH
                                    showFunctionMenu = false
                                }
                            )
                            allFunctions.forEach { func ->
                                DropdownMenuItem(
                                    text = { Text("${func.offset} - ${func.name}", color = TextPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        onSelectFunction(func)
                                        showFunctionMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedFunction?.name ?: "All Functions (Batch Mode)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        ),
                        color = TextPrimary,
                        maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    if (selectedFunction != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyanPrimary.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = selectedFunction.offset,
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                                color = CyanPrimary
                            )
                        }
                    }
                }
            }
        }

        // Template Selector Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTemplate.ordinal,
            containerColor = SlateSurface,
            contentColor = CyanPrimary,
            edgePadding = 0.dp,
            divider = {}
        ) {
            FridaSnippetGenerator.TemplateType.values().forEach { template ->
                Tab(
                    selected = selectedTemplate == template,
                    onClick = { selectedTemplate = template },
                    text = {
                        Text(
                            text = template.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTemplate == template) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Text(
            text = selectedTemplate.description,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
            color = TextSecondary
        )

        // Monospace Code Editor / Viewer Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CodeBackground)
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            val vScroll = rememberScrollState()
            val hScroll = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(vScroll)
                    .horizontalScroll(hScroll)
            ) {
                Text(
                    text = scriptCode,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = CodeString,
                    lineHeight = 16.sp
                )
            }
        }

        // Action Buttons Row (Copy & Share)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Frida Script", scriptCode))
                    Toast.makeText(context, "Script copied to clipboard!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = SlateBackground, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("COPY SCRIPT", fontWeight = FontWeight.Bold, color = SlateBackground, fontSize = 12.sp)
            }

            OutlinedButton(
                onClick = {
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, scriptCode)
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, "Share Frida Script")
                    context.startActivity(shareIntent)
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("SHARE / EXPORT", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 12.sp)
            }
        }
    }
}
