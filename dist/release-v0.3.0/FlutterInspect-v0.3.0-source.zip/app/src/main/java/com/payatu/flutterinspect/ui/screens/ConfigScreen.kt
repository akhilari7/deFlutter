package com.payatu.flutterinspect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.payatu.flutterinspect.data.models.InspectConfig
import com.payatu.flutterinspect.data.models.InstalledApp
import com.payatu.flutterinspect.ui.components.AppPickerSheet
import com.payatu.flutterinspect.ui.theme.*

@Composable
fun ConfigScreen(
    config: InspectConfig,
    installedApps: List<InstalledApp>,
    onConfigChange: (InspectConfig) -> Unit,
    onSaveConfig: () -> Unit,
    onRestartApp: () -> Unit,
    isSaving: Boolean,
    isRestarting: Boolean
) {
    var showAppPicker by remember { mutableStateOf(false) }
    var newKeywordInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    val keywordPresets = listOf("command", "login", "http", "token", "auth", "crypto", "secret", "user")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Target Process
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TARGET PROCESS",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                        color = TextMuted
                    )
                    TextButton(onClick = { showAppPicker = true }) {
                        Icon(Icons.Default.Apps, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pick App", color = CyanPrimary, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = config.process,
                    onValueChange = { onConfigChange(config.copy(process = it)) },
                    placeholder = { Text("e.g. co.ostorlab.insecure_app", color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = SlateSurfaceVariant,
                        unfocusedContainerColor = SlateSurfaceVariant
                    ),
                    singleLine = true
                )
            }
        }

        // Section: Scan Mode
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DISCOVERY MODE",
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isKeywordMode = config.mode == "keyword_search"

                    // Keyword Search Button
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isKeywordMode) CyanPrimary.copy(alpha = 0.2f) else SlateSurfaceVariant)
                            .border(
                                1.dp,
                                if (isKeywordMode) CyanPrimary else SlateBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onConfigChange(config.copy(mode = "keyword_search")) }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Keyword Search",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = if (isKeywordMode) CyanPrimary else TextSecondary
                            )
                            Text(
                                text = "Fast targeted .rodata xrefs",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp),
                                color = TextMuted
                            )
                        }
                    }

                    // Full Enumerate Button
                    val isFullMode = config.mode == "full_enumerate"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isFullMode) PurpleHighlight.copy(alpha = 0.2f) else SlateSurfaceVariant)
                            .border(
                                1.dp,
                                if (isFullMode) PurpleHighlight else SlateBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onConfigChange(config.copy(mode = "full_enumerate")) }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Full Enumerate",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = if (isFullMode) PurpleHighlight else TextSecondary
                            )
                            Text(
                                text = "Exhaustive Dart identifiers",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp),
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }

        // Section: Keywords (if in keyword_search mode)
        if (config.mode == "keyword_search") {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SEARCH KEYWORDS",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Keyword Chips Flow
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Presets
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(keywordPresets) { preset ->
                                val isSelected = config.keywords.contains(preset)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        val updated = if (isSelected) {
                                            config.keywords.filter { it != preset }
                                        } else {
                                            config.keywords + preset
                                        }
                                        onConfigChange(config.copy(keywords = updated))
                                    },
                                    label = { Text(preset, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = CyanPrimary,
                                        containerColor = SlateSurfaceVariant,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = SlateBorder,
                                        selectedBorderColor = CyanPrimary
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Active keywords list with remove
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        config.keywords.forEach { kw ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SlateSurfaceVariant)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = kw,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                    color = TextPrimary
                                )
                                IconButton(
                                    onClick = {
                                        onConfigChange(config.copy(keywords = config.keywords.filter { it != kw }))
                                    },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove",
                                        tint = RoseError,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Add custom keyword input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newKeywordInput,
                            onValueChange = { newKeywordInput = it },
                            placeholder = { Text("Add custom keyword...", color = TextMuted, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanPrimary,
                                unfocusedBorderColor = SlateBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = SlateSurfaceVariant,
                                unfocusedContainerColor = SlateSurfaceVariant
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (newKeywordInput.isNotBlank() && !config.keywords.contains(newKeywordInput.trim())) {
                                    onConfigChange(config.copy(keywords = config.keywords + newKeywordInput.trim()))
                                    newKeywordInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = SlateBackground)
                        }
                    }
                }
            }
        }

        // Section: Target Library
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "TARGET LIBRARIES",
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val hasAppSo = config.targetLibs.contains("libapp.so")
                    FilterChip(
                        selected = hasAppSo,
                        onClick = {
                            val updated = if (hasAppSo) config.targetLibs - "libapp.so" else config.targetLibs + "libapp.so"
                            onConfigChange(config.copy(targetLibs = updated))
                        },
                        label = { Text("libapp.so (User Code)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = CyanPrimary
                        )
                    )

                    val hasFlutterSo = config.targetLibs.contains("libflutter.so")
                    FilterChip(
                        selected = hasFlutterSo,
                        onClick = {
                            val updated = if (hasFlutterSo) config.targetLibs - "libflutter.so" else config.targetLibs + "libflutter.so"
                            onConfigChange(config.copy(targetLibs = updated))
                        },
                        label = { Text("libflutter.so (Engine)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = CyanPrimary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Action Buttons
        Button(
            onClick = onSaveConfig,
            enabled = !isSaving,
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            if (isSaving) {
                CircularProgressIndicator(color = SlateBackground, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.Save, contentDescription = null, tint = SlateBackground)
                Spacer(modifier = Modifier.width(8.dp))
                Text("DEPLOY CONFIG TO ZYGISK", fontWeight = FontWeight.Bold, color = SlateBackground)
            }
        }

        OutlinedButton(
            onClick = onRestartApp,
            enabled = !isRestarting,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberWarning),
            border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            if (isRestarting) {
                CircularProgressIndicator(color = AmberWarning, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AmberWarning)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SAVE & FORCE RESTART APP", fontWeight = FontWeight.Bold, color = AmberWarning)
            }
        }
    }

    if (showAppPicker) {
        AppPickerSheet(
            apps = installedApps,
            onAppSelected = { app ->
                onConfigChange(config.copy(process = app.packageName))
            },
            onDismiss = { showAppPicker = false }
        )
    }
}
