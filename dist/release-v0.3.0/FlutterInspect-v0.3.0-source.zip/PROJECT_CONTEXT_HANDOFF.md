# FlutterInspect: Project Context, Architecture & Script Reference

This document consolidates all architectural details, C++ module implementations, device configurations, Dart AOT runtime internals, and Frida instrumentation scripts created during Phase 1. Use this file as a complete context handoff for future sessions.

---

## 1. Project Overview & Architecture

**FlutterInspect** (formerly *FlutterLens*) is a specialized Zygisk module for Android designed to dynamically locate and resolve unexported Dart/Flutter AOT function addresses and base-relative offsets at runtime.

### Key Capabilities
1. **Dynamic Resolution without Symbols**: Flutter strips symbols in release builds. FlutterInspect leverages `.rodata` string cross-references (`adrp` + `add` / `ldr` instructions in ARM64 `.text`) and disassembles backward to locate enclosing function prologues using Capstone.
2. **True ASLR-Corrected Offsets**: Functions are exported with runtime addresses (`abs_addr`) and base-relative offsets (`offset = abs_addr - base_address`), ready for instant attachment via Frida (`Process.getModuleByName("libapp.so").base.add(offset)`).
3. **Dual Operating Modes**:
   - `keyword_search`: Fast targeted search for specific strings/methods (e.g. `"command"`, `"login"`, `"http"`).
   - `full_enumerate`: Exhaustive scanning across all Dart function entrypoints.

---

## 2. Directory Structure & Key Files

```
FlutterInspect/
├── module/
│   ├── build.gradle.kts           # Configured for NDK 27.2, arm64-v8a, Capstone linkage
│   ├── src/main/cpp/
│   │   ├── main.cpp               # Zygisk entrypoints (onLoad, pre/postAppSpecialize)
│   │   ├── dart_resolver.h/.cpp   # Capstone xref resolver & prologue back-tracer (256-byte window)
│   │   ├── rodata_scan.h/.cpp     # String & Dart identifier scanner
│   │   ├── mem_scan.h/.cpp        # Signal-guarded memory reader (safe_read)
│   │   ├── result_writer.h/.cpp   # JSON exporter (writes to app cache & /data/local/tmp)
│   │   ├── companion.h/.cpp       # Magisk companion root socket for SELinux-safe config loading
│   │   └── module_config.h/.cpp   # Config parser (targets, keywords, modes)
│   └── template/                  # Magisk packaging scripts (module.prop, customize.sh)
├── scripts/
│   ├── package_zip.py             # Packaging script creating flashable Magisk zip
│   ├── sample_hook_functions.js   # Generic Frida function hooker
│   ├── sample_inspect_args.js     # Generic Dart AOT argument decoder
│   ├── hook_insecure_commands_args.js # Argument inspector for insecure_commands.dart
│   └── run_frida_hook.py          # Python Frida runner with auto-attach and unbuffered logs
├── config_keyword_example.json    # Example configuration
└── PROJECT_CONTEXT_HANDOFF.md     # This reference file
```

---

## 3. The 256-Byte Scanning Window Enhancement

In `module/src/main/cpp/dart_resolver.cpp`:
* **Problem**: Dart AOT function metadata often references string literals within an enclosing descriptor chunk. The original 80-byte scanning window missed earlier entry points when Dart packed multiple function references or closures together.
* **Solution**: The scanning window was expanded to 256 bytes:
  ```cpp
  uintptr_t chunkStart = fn_ref > 64 ? fn_ref - 64 : 0;
  size_t chunkLen = 256;
  ```
* **Result**: For keyword `"command"`, matches expanded from 3 functions to **16 distinct functions**, successfully capturing all 7 entry points for `insecure_commands.dart`, 1 for `secure_commands.dart`, and 8 for `performPrivateCommand`.

---

## 4. Target Test Environment

- **Device**: OnePlus 8 (`IN2011`), Android 13 (ARM64-v8a).
- **Root & Modules**: Magisk 30.7, ReZygisk, FlutterInspect installed at `/data/adb/modules/flutterlens/`.
- **Connectivity**: Wi-Fi ADB at `10.55.55.109:5555`.
- **Frida Server**: `frida-server-17.17.0-android-arm64` running standalone in daemon mode (`-D`) on the device.
- **Target Application**: `co.ostorlab.insecure_app` (process name: `Insecure_App`), base APK contains `libapp.so`.
- **Generated JSON**: `/data/data/co.ostorlab.insecure_app/cache/flutterlens.json`.

---

## 5. Dart AOT ARM64 Runtime & Calling Conventions

Understanding these conventions allows completely generic argument decoding without source code:

### A. Dedicated Dart Stack Pointer (`x15`)
Dart ARM64 AOT does not use `sp` for Dart frames. It reserves **`x15`** as the dedicated Dart Stack Pointer.
Function prologues follow:
```arm64
stp x29, x30, [x15, #-16]!   ; Push caller FP (x29) and LR (x30) onto Dart stack
mov x29, x15                 ; Set Frame Pointer (x29) to top of Dart stack
```

### B. Frame Pointer Relative Argument Layout
The caller pushes arguments onto the Dart stack (`x15`) prior to the `blr`/`br` call. Once inside the callee:
- `[FP + 0x10]` (`[x29 + 16]`): First argument (receiver `this` instance, or first parameter).
- `[FP + 0x18]` (`[x29 + 24]`): Second argument (e.g. `String command` / `input`).
- `[FP + 0x20]` (`[x29 + 32]`): Third argument / context closure.

### C. Register Fallbacks
In certain optimized leaf functions, stub calls, and closures:
- `x0`: Receiver / Arg 0.
- `x1`: Arg 1.
- `x2`: Arg 2.
- `x3`: Arg 3.

### D. Tagged Pointer Representation (64-Bit Dart)
* **`LSB == 0` (Bit 0 is 0) -> `Smi` (Small Integer)**:
  - Value = `rawPointer >> 1`.
  - In Frida: `ptr.and(1).isNull()`, integer value is `ptr.shr(1).toString()`.
* **`LSB == 1` (Bit 0 is 1) -> `HeapObject`**:
  - Untagged Pointer = `rawPointer - 1`.
  - In Frida: `const untagged = ptr.sub(1)`.

### E. `OneByteString` Layout
Any ASCII/UTF-8 Dart string has this universal in-memory structure:
* `untagged + 0x00`: 32-bit Header word (Class ID & GC tags).
* `untagged + 0x08`: String length (stored as a tagged `Smi`! Length = `readPointer(untagged + 8) >> 1`).
* `untagged + 0x10`: Byte array of characters.

---

## 6. Inventory of Frida Scripts

### 1. `scripts/sample_hook_functions.js`
A clean, modular sample showing how to attach to offsets extracted from `flutterlens.json`:
```javascript
const TARGET_MODULE = "libapp.so";
const HOOK_TARGETS = [
    { name: "insecure_commands_entry_0", offset: 0x2b8af0 },
    { name: "insecure_commands_entry_1", offset: 0x2b8db0 }
];

function setupHooks() {
    const mod = Process.findModuleByName(TARGET_MODULE);
    if (!mod) return false;
    HOOK_TARGETS.forEach(target => {
        const targetAddr = mod.base.add(target.offset);
        Interceptor.attach(targetAddr, {
            onEnter(args) {
                console.log(`[+] Hit: ${target.name} @ ${targetAddr}`);
            }
        });
    });
    return true;
}
```

### 2. `scripts/sample_inspect_args.js`
A generic Dart value decoder demonstrating how to inspect any register or memory address:
- Safely handles `NativePointer` bitwise checks.
- Decodes `Smi`, `OneByteString`, `bool`, and `HeapObject` headers.

### 3. `scripts/hook_insecure_commands_args.js`
The specialized script used to intercept `insecure_commands.dart` across all 8 discovered offsets:
- Intercepts `0x2b8af0`, `0x2b8db0`, `0x2b9274`, `0x2b98e8`, `0x2b9c48`, `0x2b9ef4`, `0x2ba39c`, `0x2ba4e0`.
- Dumps registers `x0..x3`, `[FP + 0x10]`, `[FP + 0x18]`, `[FP + 0x20]`.
- Emits events via both `send()` and `console.log()`.

### 4. `scripts/run_frida_hook.py`
The Python Frida runner:
- Connects to `10.55.55.109:5555`.
- Attaches to `co.ostorlab.insecure_app` / `Insecure_App`.
- Flushes stdout immediately (`flush=True`) for background task logging.
- Accepts any target script: `python scripts/run_frida_hook.py scripts/<script_name>.js`.

---

## 7. Live Device Verification Summary

When clicking **"Run All"** in the Ostorlab test app:
- **Hook Triggered**: Target `#0` (`0x2b8af0`), Target `#2` (`0x2b9274`), Target `#3` (`0x2b98e8`), Target `#5` (`0x2b9ef4`).
- **Decoded Arguments**:
  - `Target #0`: `x3: String: ""`
  - `Target #2`: `[FP + 0x10]: String: ""` and `[FP + 0x18]: String: ""`
  - `Target #5`: `[FP + 0x18]: String: ""`
- **Finding**: Ostorlab's automated test harness passes an empty string `""` by default to `InsecureCommands.run("")`, which calls `executeCommand("")`. Our argument inspector accurately captured the type (`String`), length (`0`), and empty buffer value without any source code modification.

---

## 8. Is This Approach Generic for Blind Analysis?

- **Universal**: The memory layout of `Smi`, `OneByteString`, Dart heap headers, and the `x15`/`x29` frame pointer argument slots (`[FP + 0x10]`, `[FP + 0x18]`) are VM-level constants across all Flutter ARM64 release builds.
- **Blind Discovery**: Even without knowing class/method names, any string or URL searched in `.rodata` will lead to its referencing functions and allow extracting whatever arguments are passed to them at runtime.

---

## 9. Phase 2: On-Device FlutterInspect Manager App (`:app`)

Phase 2 introduces a native Android Companion & Manager Application built with **Jetpack Compose Material 3** (`com.payatu.flutterinspect`), directly integrated into the root Gradle workspace.

### Key Capabilities & Architecture
1. **Root & Namespace Isolation (`su -mm`)**:
   - Executes root commands using interactive `ProcessBuilder` with stdin piping (`\nexit\n`).
   - Uses `su -mm` (Mount Master namespace) to cross per-app mount namespaces and directly read `/data/data/<pkg>/cache/flutterlens.json`, `/data/user/0/<pkg>/cache/flutterlens.json`, and write to `/data/adb/flutterlens/config.json`.
2. **Target App Discovery**:
   - Inspects installed applications via `PackageManager`.
   - Inspects APKs and native library paths for `libflutter.so`, `libapp.so`, and `assets/flutter_assets/` to automatically highlight target Flutter apps with a distinct cyan badge.
3. **Interactive Config Editor**:
   - Process selection with integrated modal picker.
   - Discovery mode toggle: `Keyword Search` vs `Full Enumerate`.
   - Chip manager for keywords with preset security anchors (`command`, `login`, `http`, `token`, `auth`, `crypto`, `secret`, `user`) + custom keyword input.
   - Target library selection (`libapp.so` user code vs `libflutter.so` engine).
   - Instant deployment to `/data/adb/flutterlens/config.json` and one-tap force-stop + restart of the target process.
4. **Discovered Functions Explorer**:
   - Real-time search and filter across function names, base-relative offsets, and ASLR addresses.
   - Visual cards showing function name, cyan offset chip with one-tap clipboard copying, ASLR runtime address, and XREF address.
5. **Frida Studio / Code Lab**:
   - Template selection:
     - **Basic Call Tracer**: Minimalistic interceptor logging invocations and return addresses.
     - **Dart AOT Argument Inspector**: Implements the universal ARM64 Dart runtime calling convention decoders discovered in Phase 1 (`x15` Dart stack pointer, `[FP + 0x10]` receiver, `[FP + 0x18]` arg 1, `[FP + 0x20]` arg 2, registers `x0..x3`, `Smi`, and `OneByteString` length and payload extraction).
     - **Batch Multi-Hook**: Hooks all filtered functions simultaneously.
   - Interactive dropdown to switch target functions or batch mode on the fly.
   - Styled dark monospace code viewer with 1-tap **Copy Script** to clipboard and **Share / Export** via Android Intent.

### Device Test Confirmation
- Built debug APK: `app/build/outputs/apk/debug/app-debug.apk` (AGP 8.9.2, Kotlin 2.0.21, CompileSdk 35).
- Installed and verified live on **OnePlus 8 (`IN2011`, Android 13, Magisk 30.7)** at `10.55.55.109:5555`.
- Successfully verified root acquisition (`ROOT: ACTIVE`), reading of 16 resolved functions for `co.ostorlab.insecure_app`, live offset copying, and interactive Frida script generation.
